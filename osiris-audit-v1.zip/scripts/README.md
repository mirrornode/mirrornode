# Scripts

DevOps and system-maintenance scripts for MIRRORNODE.

Possible scripts include:
- CI helpers
- Local setup utilities
- Migration tools
- Deployment helpers
