# OSIRIS HUD v0

Single-screen, read-only console for rendering OSIRIS audit JSON.

Input: audit JSON  
Output: human-legible verdicts

No inference. No mutation. No scroll except results rail.
