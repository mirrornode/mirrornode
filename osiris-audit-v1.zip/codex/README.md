# MIRRORNODE Codex (Private)

Private symbolic and ROTAN material.

Includes:
- Glyphs and symbolic mappings
- Ritual structures
- Narrative frameworks
- Experimental conceptual models

This directory is **not** to be included in public documentation exports.
