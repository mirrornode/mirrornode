# MIRRORNODE Documentation

Internal engineering documents for the MIRRORNODE system.

Includes:
- Architecture notes
- API specifications
- Event schemas
- Implementation guidance

Public-facing documentation will be published separately in `codex-docs`.
