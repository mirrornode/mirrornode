# Starter Kit: Symbolic Game (ROTAN-style)

A game scaffold using MIRRORNODE and ROTAN structures.

Features:
- Symbolic state machine architecture
- Narrative-driven event loops
- All logic imported from `mirrornode-core`
- One-click deploy support

Thin-client model for maximum scalability.
