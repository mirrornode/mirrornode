# Starter Kit: AI Dashboard

A rapidly deployable dashboard template powered by MIRRORNODE.

Features:
- Pulls metrics and events from `theia-core`
- Displays them using a clean UI template
- Thin client: all intelligence imported from `mirrornode-core`

Intended for Vercel one-click deploy.
