# Tests

Global test suite for MIRRORNODE.

Includes:
- Core integration tests
- Contract tests for the gateway and core
- Smoke tests for all starter-kits

Ensures system-wide coherence.
